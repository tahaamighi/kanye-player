package com.example.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.local.AppSettings
import com.example.data.local.EqSettings
import com.example.data.local.MusicDatabase
import com.example.data.local.Playlist
import com.example.data.local.Track
import com.example.data.remote.LyricLine
import com.example.data.remote.LyricsService
import com.example.data.repository.MusicRepository
import com.example.player.MusicPlayerEngine
import com.example.widget.KanyePlayerWidgetProvider
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class SortType {
    object Title : SortType()
    object Album : SortType()
    object Year : SortType()
}

class MusicViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "MusicViewModel"

    // Database & Repository Initialization
    private val database = Room.databaseBuilder(
        application,
        MusicDatabase::class.java,
        "kanye_player_database"
    ).fallbackToDestructiveMigration().build()

    private val repository = MusicRepository(database.musicDao())
    val playerEngine = MusicPlayerEngine(application)

    // UI Search & Sort States
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _sortType = MutableStateFlow<SortType>(SortType.Title)
    val sortType = _sortType.asStateFlow()

    // Playlist Selection
    private val _selectedPlaylistId = MutableStateFlow<Int?>(null)
    val selectedPlaylistId = _selectedPlaylistId.asStateFlow()

    // Synced Lyrics States
    private val _syncedLyrics = MutableStateFlow<List<LyricLine>>(emptyList())
    val syncedLyrics: StateFlow<List<LyricLine>> = _syncedLyrics.asStateFlow()

    private val _activeLyricIndex = MutableStateFlow(-1)
    val activeLyricIndex: StateFlow<Int> = _activeLyricIndex.asStateFlow()

    private val _isLyricsLoading = MutableStateFlow(false)
    val isLyricsLoading = _isLyricsLoading.asStateFlow()

    // Equalizer UI States (Current sliders in use)
    private val _activePresetName = MutableStateFlow("Yeezus Bass Boost")
    val activePresetName = _activePresetName.asStateFlow()

    private val _eqBand60 = MutableStateFlow(0.8f)
    val eqBand60 = _eqBand60.asStateFlow()

    private val _eqBand230 = MutableStateFlow(0.7f)
    val eqBand230 = _eqBand230.asStateFlow()

    private val _eqBand910 = MutableStateFlow(0.4f)
    val eqBand910 = _eqBand910.asStateFlow()

    private val _eqBand4k = MutableStateFlow(0.5f)
    val eqBand4k = _eqBand4k.asStateFlow()

    private val _eqBand14k = MutableStateFlow(0.6f)
    val eqBand14k = _eqBand14k.asStateFlow()

    private val _eqBassBoost = MutableStateFlow(0.9f)
    val eqBassBoost = _eqBassBoost.asStateFlow()

    private val _eqVirtualizer = MutableStateFlow(0.6f)
    val eqVirtualizer = _eqVirtualizer.asStateFlow()

    // Offline Files Settings State
    private val _offlinePathsScanResult = MutableStateFlow<String?>(null)
    val offlinePathsScanResult = _offlinePathsScanResult.asStateFlow()

    // Observed Data from Room
    val playlists: StateFlow<List<Playlist>> = repository.allPlaylists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appSettings: StateFlow<AppSettings?> = repository.appSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Combined filtered & sorted tracks
    @OptIn(FlowPreview::class)
    val tracks: StateFlow<List<Track>> = combine(
        repository.allTracks,
        _searchQuery.debounce(150),
        _sortType,
        _selectedPlaylistId
    ) { allTracks, query, sort, playlistId ->
        var list = if (playlistId != null) {
            // Filter by playlist
            repository.getPlaylistWithTracks(playlistId).firstOrNull()?.tracks ?: emptyList()
        } else {
            allTracks
        }

        // Apply Search
        if (query.isNotEmpty()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.album.contains(query, ignoreCase = true) ||
                        it.artist.contains(query, ignoreCase = true)
            }
        }

        // Apply Sorting
        when (sort) {
            SortType.Title -> list.sortedBy { it.title }
            SortType.Album -> list.sortedWith(compareBy<Track> { it.album }.thenBy { it.title })
            SortType.Year -> list.sortedWith(compareBy<Track> { it.year }.thenBy { it.title })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically check if tracks exist. If empty, seed database with premium demo Kanye tracks!
        viewModelScope.launch {
            val count = database.musicDao().getAllTracks().firstOrNull()?.size ?: 0
            if (count == 0) {
                Log.d(TAG, "Database empty, seeding beautiful demo Yeezy songs...")
                repository.seedDemoYeezyTracks()
            }
            
            // Apply loaded app settings
            repository.appSettings.firstOrNull()?.let {
                playerEngine.setAutoConnectCarBt(it.autoConnectBluetooth)
                _activePresetName.value = it.activePreset
                applyEqPreset(it.activePreset)
            }
        }

        // Keep player states synchronized and update Home Screen Widget automatically on track updates!
        combine(playerEngine.currentTrack, playerEngine.isPlaying) { track, playing ->
            if (track != null) {
                KanyePlayerWidgetProvider.updateWidgetState(
                    getApplication(),
                    track.title,
                    track.artist,
                    playing
                )
                
                // When current track changes, fetch its synced lyrics online!
                _isLyricsLoading.value = true
                viewModelScope.launch {
                    val lyrics = LyricsService.fetchSyncedLyrics(track.title, track.artist)
                    _syncedLyrics.value = lyrics
                    _isLyricsLoading.value = false
                }
            } else {
                KanyePlayerWidgetProvider.updateWidgetState(
                    getApplication(),
                    "Yeezy Player",
                    "Offline Player",
                    false
                )
            }
        }.launchIn(viewModelScope)

        // Real-time listener for current position to auto-scroll synced lyrics
        playerEngine.currentPositionMs.onEach { positionMs ->
            val lyrics = _syncedLyrics.value
            if (lyrics.isNotEmpty()) {
                var index = -1
                for (i in lyrics.indices) {
                    if (positionMs >= lyrics[i].timestampMs) {
                        index = i
                    } else {
                        break
                    }
                }
                _activeLyricIndex.value = index
            }
        }.launchIn(viewModelScope)
    }

    // Search and Filters
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortType(type: SortType) {
        _sortType.value = type
    }

    fun selectPlaylist(playlistId: Int?) {
        _selectedPlaylistId.value = playlistId
    }

    // Media Controllers
    fun playTrack(track: Track) {
        val list = tracks.value
        val index = list.indexOf(track)
        playerEngine.setQueue(list, if (index != -1) index else 0)
    }

    // Database Actions
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.insertPlaylist(name)
        }
    }

    fun deletePlaylist(playlist: Playlist) {
        viewModelScope.launch {
            repository.deletePlaylist(playlist)
            if (_selectedPlaylistId.value == playlist.id) {
                _selectedPlaylistId.value = null
            }
        }
    }

    fun addTrackToPlaylist(playlistId: Int, trackId: Int) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackId)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Int, trackId: Int) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackId)
        }
    }

    fun toggleFavorite(track: Track) {
        viewModelScope.launch {
            val updated = track.copy(isFavorite = !track.isFavorite)
            repository.updateTrack(updated)
            
            // Add or remove from Faves playlist
            val playlistsList = playlists.value
            val favoritesPlaylist = playlistsList.find { it.name == "My Faves" }
            if (favoritesPlaylist != null) {
                if (updated.isFavorite) {
                    repository.addTrackToPlaylist(favoritesPlaylist.id, updated.id)
                } else {
                    repository.removeTrackFromPlaylist(favoritesPlaylist.id, updated.id)
                }
            }
        }
    }

    // Equalizer Adjustments
    fun setEqBand(band: String, value: Float) {
        when (band) {
            "60Hz" -> _eqBand60.value = value
            "230Hz" -> _eqBand230.value = value
            "910Hz" -> _eqBand910.value = value
            "4kHz" -> _eqBand4k.value = value
            "14kHz" -> _eqBand14k.value = value
            "bass" -> _eqBassBoost.value = value
            "virtualizer" -> _eqVirtualizer.value = value
        }
        _activePresetName.value = "Custom"
        saveEqualizerToDb()
    }

    fun applyEqPreset(name: String) {
        _activePresetName.value = name
        viewModelScope.launch {
            val settings = repository.getEqSettings(name)
            _eqBand60.value = settings.band60
            _eqBand230.value = settings.band230
            _eqBand910.value = settings.band910
            _eqBand4k.value = settings.band4k
            _eqBand14k.value = settings.band14k
            _eqBassBoost.value = settings.bassBoost
            _eqVirtualizer.value = settings.virtualizer

            // Update app settings in DB
            val currentSettings = appSettings.value ?: AppSettings()
            repository.saveAppSettings(currentSettings.copy(activePreset = name))
        }
    }

    private fun saveEqualizerToDb() {
        viewModelScope.launch {
            val preset = _activePresetName.value
            val settings = EqSettings(
                presetName = preset,
                band60 = _eqBand60.value,
                band230 = _eqBand230.value,
                band910 = _eqBand910.value,
                band4k = _eqBand4k.value,
                band14k = _eqBand14k.value,
                bassBoost = _eqBassBoost.value,
                virtualizer = _eqVirtualizer.value
            )
            repository.saveEqSettings(settings)

            val currentSettings = appSettings.value ?: AppSettings()
            repository.saveAppSettings(currentSettings.copy(activePreset = preset))
        }
    }

    // Folder scanning logic
    fun scanUserDirectory(directoryPath: String) {
        viewModelScope.launch {
            _offlinePathsScanResult.value = "Scanning folder..."
            try {
                val detectedCount = repository.scanDirectoryForYeezyTracks(directoryPath)
                if (detectedCount > 0) {
                    _offlinePathsScanResult.value = "Scanning completed! Found $detectedCount Ye/Kanye track(s) and automatically saved them offline."
                    
                    // Update app settings folder path
                    val currentSettings = appSettings.value ?: AppSettings()
                    repository.saveAppSettings(currentSettings.copy(lastSelectedFolderPath = directoryPath))
                } else {
                    _offlinePathsScanResult.value = "Scan complete. No Kanye West or Ye songs were identified in this folder. Tap 'Generate Seed Tracks' below to test with premium offline music."
                }
            } catch (e: Exception) {
                _offlinePathsScanResult.value = "Scan failed: ${e.message}"
            }
        }
    }

    fun resetOfflineCacheAndReSeed() {
        viewModelScope.launch {
            _offlinePathsScanResult.value = "Resetting player database..."
            repository.seedDemoYeezyTracks()
            _offlinePathsScanResult.value = "Database successfully re-seeded with 12 classic Yeezy offline tracks!"
        }
    }

    fun toggleAutoConnectCarBt(enabled: Boolean) {
        playerEngine.setAutoConnectCarBt(enabled)
        viewModelScope.launch {
            val currentSettings = appSettings.value ?: AppSettings()
            repository.saveAppSettings(currentSettings.copy(autoConnectBluetooth = enabled))
        }
    }
}
