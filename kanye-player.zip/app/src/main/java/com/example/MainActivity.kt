package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.MainPlayerScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MusicViewModel
import com.example.widget.KanyePlayerWidgetProvider

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: MusicViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize our Master Music State ViewModel
        viewModel = ViewModelProvider(this)[MusicViewModel::class.java]

        // Handle initial intents from widget if app was closed
        intent?.let { handleWidgetIntent(it) }

        setContent {
            MyApplicationTheme {
                MainPlayerScreen(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleWidgetIntent(intent)
    }

    private fun handleWidgetIntent(intent: Intent) {
        when (intent.action) {
            KanyePlayerWidgetProvider.ACTION_WIDGET_PLAY_PAUSE -> {
                val engine = viewModel.playerEngine
                if (engine.isPlaying.value) {
                    engine.pausePlayback()
                } else {
                    engine.resumePlayback()
                }
            }
            KanyePlayerWidgetProvider.ACTION_WIDGET_NEXT -> {
                viewModel.playerEngine.nextTrack()
            }
        }
    }
}
