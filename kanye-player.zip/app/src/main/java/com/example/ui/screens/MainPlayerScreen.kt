package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothSearching
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.Playlist
import com.example.data.local.Track
import com.example.player.MusicPlayerEngine
import com.example.viewmodel.MusicViewModel
import com.example.viewmodel.SortType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainPlayerScreen(viewModel: MusicViewModel) {
    var activeTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val currentTrack by viewModel.playerEngine.currentTrack.collectAsState()
    val isPlaying by viewModel.playerEngine.isPlaying.collectAsState()

    // Base Scaffold using Edge-to-Edge window inset rules
    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF070707),
                modifier = Modifier
                    .border(1.dp, Color(0xFF151515), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = "Archive") },
                    label = { Text("آرشیو", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        unselectedIconColor = Color(0xFF555555),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color(0xFF555555),
                        indicatorColor = Color(0xFF1E1E1E)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Filled.MusicNote, contentDescription = "Now Playing") },
                    label = { Text("پخش", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        unselectedIconColor = Color(0xFF555555),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color(0xFF555555),
                        indicatorColor = Color(0xFF1E1E1E)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Filled.Equalizer, contentDescription = "Equalizer") },
                    label = { Text("اکولایزر", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        unselectedIconColor = Color(0xFF555555),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color(0xFF555555),
                        indicatorColor = Color(0xFF1E1E1E)
                    )
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Filled.Bluetooth, contentDescription = "Bluetooth & Settings") },
                    label = { Text("اتصال و آفلاین", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        unselectedIconColor = Color(0xFF555555),
                        selectedTextColor = Color.White,
                        unselectedTextColor = Color(0xFF555555),
                        indicatorColor = Color(0xFF1E1E1E)
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(innerPadding)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Elegant Brutalist Brand Top Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "KANYE PLAYER",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "کانیه پلیر  |  رادیو موزیک اختصاصی",
                        color = Color(0xFFFF0033),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                
                // Mini indicator of playing state
                if (currentTrack != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Color(0xFF0F0F0F), RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF1A1A1A), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .clickable { activeTab = 1 }
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.PlayArrow else Icons.Filled.Pause,
                            contentDescription = "Playing",
                            tint = Color(0xFFFF0033),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentTrack!!.title,
                            color = Color.White,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.width(80.dp)
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
            ) {
                when (activeTab) {
                    0 -> ArchiveTab(viewModel)
                    1 -> NowPlayingTab(viewModel)
                    2 -> EqualizerTab(viewModel)
                    3 -> BluetoothAndSettingsTab(viewModel)
                }
            }
        }
    }
}

// --- TAB 1: ARCHIVE & FOLDERS ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveTab(viewModel: MusicViewModel) {
    val tracks by viewModel.tracks.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val selectedPlaylistId by viewModel.selectedPlaylistId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortType by viewModel.sortType.collectAsState()

    var showAddPlaylistDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    
    var showFolderScanDialog by remember { mutableStateOf(false) }
    var folderPathToScan by remember { mutableStateOf("/storage/emulated/0/Music/Yeezy") }
    val scanResult by viewModel.offlinePathsScanResult.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Hero Graphic Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .padding(vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            border = borderStroke()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_kanye_player_banner),
                    contentDescription = "Yeezy Brutalist Artwork",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                            )
                        )
                )
                Text(
                    text = "DONDA ARCHIVE: PLAY OFFLINE",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp),
                    letterSpacing = 1.sp
                )
            }
        }

        // Custom Folder Scan Trigger bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0A0A0A), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF151515), RoundedCornerShape(8.dp))
                .clickable { showFolderScanDialog = true }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.FolderSpecial, contentDescription = "Folder", tint = Color(0xFFFF0033))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("شناسایی خودکار آهنگ‌های Kanye & Ye", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("اسکن پوشه انتخابی برای فایل‌های آفلاین", color = Color.Gray, fontSize = 10.sp)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = "Scan", tint = Color.White)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Field with Brutalist Styling
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input"),
            placeholder = { Text("جستجو در بین آهنگ‌ها...", color = Color.Gray, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.Gray) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFFFF0033),
                unfocusedBorderColor = Color(0xFF151515),
                focusedContainerColor = Color(0xFF050505),
                unfocusedContainerColor = Color(0xFF050505)
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Playlists horizontal scroller
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { showAddPlaylistDialog = true },
                modifier = Modifier
                    .size(32.dp)
                    .background(Color(0xFFFF0033), RoundedCornerShape(6.dp))
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Add Playlist", tint = Color.White, modifier = Modifier.size(18.dp))
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Scrollable Row for Custom Playlists
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                item {
                    PlaylistChip(
                        name = "همه آهنگ‌ها",
                        isSelected = selectedPlaylistId == null,
                        onClick = { viewModel.selectPlaylist(null) }
                    )
                }
                items(playlists) { playlist ->
                    PlaylistChip(
                        name = playlist.name,
                        isSelected = selectedPlaylistId == playlist.id,
                        onClick = { viewModel.selectPlaylist(playlist.id) },
                        onDelete = { viewModel.deletePlaylist(playlist) }
                    )
                }
            }
        }

        // Sorting Controls (Title, Album, Release Year)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("مرتب‌سازی بر اساس:", color = Color.Gray, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SortChip(text = "عنوان", isSelected = sortType is SortType.Title) {
                    viewModel.setSortType(SortType.Title)
                }
                SortChip(text = "آلبوم", isSelected = sortType is SortType.Album) {
                    viewModel.setSortType(SortType.Album)
                }
                SortChip(text = "سال انتشار", isSelected = sortType is SortType.Year) {
                    viewModel.setSortType(SortType.Year)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Tracks List
        if (tracks.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.MusicNote, contentDescription = "No music", tint = Color(0xFF222222), modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("هیچ آهنگی یافت نشد", color = Color.Gray, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("از منوی زیر می‌توانید مخزن را ریست کنید", color = Color(0xFF555555), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(tracks) { track ->
                    TrackRowItem(
                        track = track,
                        onPlay = { viewModel.playTrack(track) },
                        onFavoriteToggle = { viewModel.toggleFavorite(track) },
                        playlists = playlists,
                        onAddToPlaylist = { pId -> viewModel.addTrackToPlaylist(pId, track.id) }
                    )
                }
            }
        }
    }

    // --- Add Playlist Dialog ---
    if (showAddPlaylistDialog) {
        AlertDialog(
            onDismissRequest = { showAddPlaylistDialog = false },
            containerColor = Color(0xFF0F0F0F),
            title = { Text("ساخت لیست پخش جدید", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    placeholder = { Text("نام لیست پخش...") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFFF0033),
                        unfocusedBorderColor = Color(0xFF222222),
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            viewModel.createPlaylist(newPlaylistName)
                            newPlaylistName = ""
                            showAddPlaylistDialog = false
                        }
                    }
                ) {
                    Text("ایجاد", color = Color(0xFFFF0033))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddPlaylistDialog = false }) {
                    Text("انصراف", color = Color.Gray)
                }
            }
        )
    }

    // --- Folder Scan Dialog ---
    if (showFolderScanDialog) {
        AlertDialog(
            onDismissRequest = { showFolderScanDialog = false },
            containerColor = Color(0xFF0A0A0A),
            modifier = Modifier.border(1.dp, Color(0xFF222222), RoundedCornerShape(28.dp)),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Folder, contentDescription = "Folder", tint = Color(0xFFFF0033))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("انتخاب و اسکن خودکار پوشه", color = Color.White, fontSize = 16.sp)
                }
            },
            text = {
                Column {
                    Text(
                        text = "آدرس پوشه موسیقی را وارد کنید. برنامه بصورت خودکار آهنگ‌های مربوط به Kanye West, Kanye و Ye را شناسایی و به آرشیو آفلاین شما اضافه خواهد کرد.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = folderPathToScan,
                        onValueChange = { folderPathToScan = it },
                        label = { Text("مسیر پوشه", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFFF0033),
                            unfocusedBorderColor = Color(0xFF333333),
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )
                    
                    if (scanResult != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = scanResult!!,
                            color = Color(0xFFFF0033),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.scanUserDirectory(folderPathToScan) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0033))
                ) {
                    Text("اسکن", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFolderScanDialog = false }) {
                    Text("بستن", color = Color.Gray)
                }
            }
        )
    }
}

// Custom Border stroke generator
private fun borderStroke() = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF151515))

@Composable
fun PlaylistChip(
    name: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .background(
                color = if (isSelected) Color(0xFFFF0033) else Color(0xFF0F0F0F),
                shape = RoundedCornerShape(8.dp)
            )
            .border(
                1.dp,
                if (isSelected) Color(0xFFFF0033) else Color(0xFF222222),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = name,
            color = if (isSelected) Color.White else Color.LightGray,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        if (onDelete != null && !isSelected) {
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                Icons.Filled.Delete,
                contentDescription = "Delete",
                tint = Color.Gray,
                modifier = Modifier
                    .size(14.dp)
                    .clickable { onDelete() }
            )
        }
    }
}

@Composable
fun SortChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Text(
        text = text,
        color = if (isSelected) Color.White else Color.Gray,
        fontSize = 11.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
        modifier = Modifier
            .background(
                if (isSelected) Color(0xFF1E1E1E) else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .border(
                1.dp,
                if (isSelected) Color(0xFF333333) else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackRowItem(
    track: Track,
    onPlay: () -> Unit,
    onFavoriteToggle: () -> Unit,
    playlists: List<Playlist>,
    onAddToPlaylist: (Int) -> Unit
) {
    var showPlaylistMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF050505), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF101010), RoundedCornerShape(8.dp))
            .clickable { onPlay() }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Minimal album code placeholder
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(Color(0xFF1A1A1A), RoundedCornerShape(4.dp))
                .border(1.dp, Color(0xFF333333), RoundedCornerShape(4.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, contentDescription = "Note", tint = Color.White, modifier = Modifier.size(16.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${track.album} • ${track.year}",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Add to playlist button
        IconButton(onClick = { showPlaylistMenu = true }) {
            Icon(Icons.Filled.Add, contentDescription = "Add to playlist", tint = Color.Gray, modifier = Modifier.size(18.dp))
        }

        // Favorite Toggle
        IconButton(onClick = onFavoriteToggle) {
            Icon(
                imageVector = if (track.isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Fav",
                tint = if (track.isFavorite) Color(0xFFFF0033) else Color.Gray,
                modifier = Modifier.size(18.dp)
            )
        }
    }

    if (showPlaylistMenu) {
        AlertDialog(
            onDismissRequest = { showPlaylistMenu = false },
            containerColor = Color(0xFF0F0F0F),
            title = { Text("افزودن به لیست پخش", color = Color.White, fontSize = 14.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (playlists.isEmpty()) {
                        Text("لیست پخشی یافت نشد. ابتدا یکی بسازید.", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        playlists.forEach { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onAddToPlaylist(playlist.id)
                                        showPlaylistMenu = false
                                    }
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(playlist.name, color = Color.White, fontSize = 13.sp)
                                Icon(Icons.Filled.Add, contentDescription = "Add", tint = Color(0xFFFF0033), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showPlaylistMenu = false }) {
                    Text("بستن", color = Color.Gray)
                }
            }
        )
    }
}


// --- TAB 2: NOW PLAYING & LYRICS ---
@Composable
fun NowPlayingTab(viewModel: MusicViewModel) {
    val currentTrack by viewModel.playerEngine.currentTrack.collectAsState()
    val isPlaying by viewModel.playerEngine.isPlaying.collectAsState()
    val currentPositionMs by viewModel.playerEngine.currentPositionMs.collectAsState()
    val isShuffle by viewModel.playerEngine.isShuffleEnabled.collectAsState()
    val isRepeat by viewModel.playerEngine.isRepeatEnabled.collectAsState()

    val syncedLyrics by viewModel.syncedLyrics.collectAsState()
    val activeLyricIndex by viewModel.activeLyricIndex.collectAsState()
    val isLyricsLoading by viewModel.isLyricsLoading.collectAsState()

    // Smooth Infinite Rotating Vinyl Animation if track is playing
    val infiniteTransition = rememberInfiniteTransition(label = "vinyl_spin")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "angle"
    )
    val animatedAngle = if (isPlaying) angle else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (currentTrack == null) {
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.LibraryMusic,
                        contentDescription = "No Active Song",
                        tint = Color(0xFF222222),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("آهنگی در حال پخش نیست", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("یک آهنگ از لیست آرشیو برای پخش انتخاب کنید", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        } else {
            val track = currentTrack!!

            Spacer(modifier = Modifier.height(16.dp))

            // Immersive Vinyl Design
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .rotate(animatedAngle)
                    .background(Color(0xFF0F0F0F), CircleShape)
                    .border(4.dp, Color(0xFF1E1E1E), CircleShape)
                    .drawBehind {
                        // Drawing subtle brutalist record rings
                        drawCircle(Color.Black, size.width / 2f - 10f, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                        drawCircle(Color.Black, size.width / 2f - 30f, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                        drawCircle(Color.Black, size.width / 2f - 50f, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                    },
                contentAlignment = Alignment.Center
            ) {
                // Outer glow
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .background(Color(0xFFFF0033), CircleShape)
                        .border(2.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("YE", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Metadata Detail
            Text(
                text = track.title,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${track.artist}  |  ${track.album} (${track.year})",
                color = Color(0xFFFF0033),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Scroller Slider Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTime(currentPositionMs),
                    color = Color.Gray,
                    fontSize = 10.sp
                )
                
                Slider(
                    value = currentPositionMs.toFloat(),
                    onValueChange = { viewModel.playerEngine.seekTo(it.toLong()) },
                    valueRange = 0f..track.durationMs.toFloat(),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Color(0xFFFF0033),
                        inactiveTrackColor = Color(0xFF111111)
                    )
                )

                Text(
                    text = formatTime(track.durationMs),
                    color = Color.Gray,
                    fontSize = 10.sp
                )
            }

            // Minimal Controls Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle
                IconButton(onClick = { viewModel.playerEngine.toggleShuffle() }) {
                    Icon(
                        imageVector = Icons.Filled.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) Color(0xFFFF0033) else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Previous
                IconButton(onClick = { viewModel.playerEngine.prevTrack() }) {
                    Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(24.dp))
                }

                // PLAY/PAUSE with huge circular neon red background
                IconButton(
                    onClick = {
                        if (isPlaying) viewModel.playerEngine.pausePlayback() else viewModel.playerEngine.resumePlayback()
                    },
                    modifier = Modifier
                        .size(54.dp)
                        .background(Color(0xFFFF0033), CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Next
                IconButton(onClick = { viewModel.playerEngine.nextTrack() }) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(24.dp))
                }

                // Repeat
                IconButton(onClick = { viewModel.playerEngine.toggleRepeat() }) {
                    Icon(
                        imageVector = Icons.Filled.Repeat,
                        contentDescription = "Repeat",
                        tint = if (isRepeat) Color(0xFFFF0033) else Color.Gray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Synchronized Lyrics Scroller Layout (Online Lyrics service)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF040404), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF121212), RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("متن ترانه همگام‌سازی شده", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(Color(0xFF00FF66), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("سرویس آنلاین Gemini", color = Color.Gray, fontSize = 9.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (isLyricsLoading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color(0xFFFF0033), modifier = Modifier.size(28.dp))
                    }
                } else if (syncedLyrics.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("متن ترانه‌ای برای این آهنگ یافت نشد", color = Color.Gray, fontSize = 11.sp)
                    }
                } else {
                    val lyricsListState = rememberLazyListState()
                    
                    // Auto-scroll lyrics list based on current active lyric line
                    LaunchedEffect(activeLyricIndex) {
                        if (activeLyricIndex >= 0) {
                            lyricsListState.animateScrollToItem(activeLyricIndex)
                        }
                    }

                    LazyColumn(
                        state = lyricsListState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(syncedLyrics.size) { index ->
                            val line = syncedLyrics[index]
                            val isActive = index == activeLyricIndex
                            val textColor by animateColorAsState(
                                targetValue = if (isActive) Color.White else Color(0xFF3A3A3A),
                                label = "lyrics_color"
                            )
                            val fontSize = if (isActive) 14.sp else 12.sp
                            val fontWeight = if (isActive) FontWeight.Black else FontWeight.Normal

                            Text(
                                text = line.text,
                                color = textColor,
                                fontSize = fontSize,
                                fontWeight = fontWeight,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSecs = ms / 1000
    val minutes = totalSecs / 60
    val seconds = totalSecs % 60
    return String.format("%02d:%02d", minutes, seconds)
}


// --- TAB 3: STUDIO EQUALIZER ---
@Composable
fun EqualizerTab(viewModel: MusicViewModel) {
    val activePreset by viewModel.activePresetName.collectAsState()
    val band60 by viewModel.eqBand60.collectAsState()
    val band230 by viewModel.eqBand230.collectAsState()
    val band910 by viewModel.eqBand910.collectAsState()
    val band4k by viewModel.eqBand4k.collectAsState()
    val band14k by viewModel.eqBand14k.collectAsState()
    val bassBoost by viewModel.eqBassBoost.collectAsState()
    val virtualizer by viewModel.eqVirtualizer.collectAsState()

    val presets = listOf("Yeezus Bass Boost", "Graduation Synth", "808s Autotune", "Acoustic Minimalist", "Donda Ambient", "Normal")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Text("اکولایزر پیشرفته کانیه", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        
        // Preset selectors
        androidx.compose.foundation.lazy.LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            items(presets) { preset ->
                val isSelected = activePreset == preset
                Text(
                    text = preset,
                    color = if (isSelected) Color.White else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier
                        .background(
                            if (isSelected) Color(0xFFFF0033) else Color(0xFF0F0F0F),
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            if (isSelected) Color(0xFFFF0033) else Color(0xFF222222),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { viewModel.applyEqPreset(preset) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }

        // Horizontal Grid of vertical frequency sliders (Pure M3 minimalist look)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF030303)),
            border = borderStroke()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                EqualizerSliderColumn("60Hz", band60) { viewModel.setEqBand("60Hz", it) }
                EqualizerSliderColumn("230Hz", band230) { viewModel.setEqBand("230Hz", it) }
                EqualizerSliderColumn("910Hz", band910) { viewModel.setEqBand("910Hz", it) }
                EqualizerSliderColumn("4kHz", band4k) { viewModel.setEqBand("4kHz", it) }
                EqualizerSliderColumn("14kHz", band14k) { viewModel.setEqBand("14kHz", it) }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dual dial sliders for Bass Boost and Virtualizer spatial sound
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Bass Boost Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(90.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF070707)),
                border = borderStroke()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("BASS BOOST", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${(bassBoost * 100).toInt()}%", color = Color(0xFFFF0033), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                    Slider(
                        value = bassBoost,
                        onValueChange = { viewModel.setEqBand("bass", it) },
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color(0xFFFF0033),
                            inactiveTrackColor = Color(0xFF151515)
                        )
                    )
                }
            }

            // Virtualizer Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(90.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF070707)),
                border = borderStroke()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("VIRTUALIZER", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("${(virtualizer * 100).toInt()}%", color = Color(0xFFFF0033), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                    Slider(
                        value = virtualizer,
                        onValueChange = { viewModel.setEqBand("virtualizer", it) },
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color(0xFFFF0033),
                            inactiveTrackColor = Color(0xFF151515)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun EqualizerSliderColumn(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "${(value * 24 - 12).toInt()} dB",
            color = Color(0xFFFF0033),
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
        )

        // Custom Rotated Slider for vertical visual representation of the faders
        Box(
            modifier = Modifier
                .weight(1f)
                .width(24.dp)
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Slider(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .graphicsLayer(rotationZ = -90f)
                    .fillMaxHeight(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color(0xFF1A1A1A)
                )
            )
        }

        Text(text = label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}


// --- TAB 4: BLUETOOTH & OFFLINE SETTINGS ---
@Composable
fun BluetoothAndSettingsTab(viewModel: MusicViewModel) {
    val bluetoothDevices by viewModel.playerEngine.bluetoothDevices.collectAsState()
    val isScanning by viewModel.playerEngine.isBtScanning.collectAsState()
    val connectedDeviceName by viewModel.playerEngine.connectedBtDeviceName.collectAsState()
    val autoConnectCarBt by viewModel.playerEngine.autoConnectCarBt.collectAsState()
    val scanResult by viewModel.offlinePathsScanResult.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Segment 1: Smart Car Bluetooth Engine
        Text("اتصال هوشمند بلوتوث ماشین", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
        
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF050505)),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("اتصال خودکار به ضبط ماشین", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("شناسایی و اتصال اتوماتیک در خودرو", color = Color.Gray, fontSize = 10.sp)
                    }
                    Switch(
                        checked = autoConnectCarBt,
                        onCheckedChange = { viewModel.toggleAutoConnectCarBt(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFFFF0033),
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color(0xFF151515)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (connectedDeviceName != null) "متصل به: $connectedDeviceName" else "بدون اتصال فعال",
                        color = if (connectedDeviceName != null) Color(0xFFFF0033) else Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    
                    Button(
                        onClick = { viewModel.playerEngine.startBluetoothScan() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A1A1A)),
                        border = borderStroke()
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.BluetoothSearching, contentDescription = "Scan", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("جستجو ضبط", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bluetooth paired/scanned list
        Text("دستگاه‌های صوتی جفت شده", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
        
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .background(Color(0xFF030303), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF101010), RoundedCornerShape(8.dp))
        ) {
            items(bluetoothDevices) { device ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (device.isConnected) {
                                viewModel.playerEngine.disconnectBluetooth()
                            } else {
                                viewModel.playerEngine.connectToBluetoothDevice(device)
                            }
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (device.isConnected) Icons.Filled.BluetoothConnected else Icons.Filled.Bluetooth,
                            contentDescription = "BT",
                            tint = if (device.isConnected) Color(0xFFFF0033) else Color.Gray
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(device.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                text = if (device.isCarDevice) "دستگاه خودرو  •  ${device.address}" else "بلندگو/هدفون  •  ${device.address}",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                    }
                    if (device.isConnecting) {
                        CircularProgressIndicator(color = Color(0xFFFF0033), modifier = Modifier.size(14.dp))
                    } else if (device.isConnected) {
                        Text("متصل", color = Color(0xFFFF0033), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Segment 2: Storage & Offline settings
        Text("تنظیمات دسترسی آفلاین و حافظه", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF050505)),
            border = borderStroke()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مدیریت حافظه کش آهنگ‌ها", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text("کل حافظه صوتی ذخیره شده آفلاین", color = Color.Gray, fontSize = 10.sp)
                    }
                    Text("۱۲ فایل (۱۸۴ مگابایت)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Delete cache / Re-seed action
                Button(
                    onClick = { viewModel.resetOfflineCacheAndReSeed() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF101010)),
                    border = borderStroke()
                ) {
                    Icon(Icons.Filled.Storage, contentDescription = "Reset DB", tint = Color.Gray)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ریست حافظه کش و راه‌اندازی مجدد مخزن", color = Color.White, fontSize = 12.sp)
                }
                
                if (scanResult != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(scanResult!!, color = Color(0xFFFF0033), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
