package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val YeezyBlack = Color(0xFF000000)
val YeezyDarkGray = Color(0xFF0A0A0A)
val YeezyMatteGray = Color(0xFF1E1E1E)
val YeezyLightGray = Color(0xFF8E8E93)
val YeezyWhite = Color(0xFFFFFFFF)
val YeezyCrimson = Color(0xFFFF0033) // Iconic neon crimson red accent from Yeezus tape
val YeezyAmber = Color(0xFFFF9500)   // Subtle gold accent

