package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R

class KanyePlayerWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_WIDGET_PLAY_PAUSE = "com.example.ACTION_WIDGET_PLAY_PAUSE"
        const val ACTION_WIDGET_NEXT = "com.example.ACTION_WIDGET_NEXT"

        private var currentTitle = "Yeezy Player"
        private var currentArtist = "Offline Player"
        private var isPlaying = false

        /**
         * Standard static helper to trigger an update from the main app ViewModel/Service.
         */
        fun updateWidgetState(context: Context, title: String, artist: String, playing: Boolean) {
            currentTitle = title
            currentArtist = artist
            isPlaying = playing

            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, KanyePlayerWidgetProvider::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            
            val intent = Intent(context, KanyePlayerWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, appWidgetIds)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_WIDGET_PLAY_PAUSE -> {
                // Broadcast to the activity or handle toggle
                isPlaying = !isPlaying
                val appIntent = Intent(context, MainActivity::class.java).apply {
                    action = ACTION_WIDGET_PLAY_PAUSE
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                context.startActivity(appIntent)
                updateAllWidgets(context)
            }
            ACTION_WIDGET_NEXT -> {
                val appIntent = Intent(context, MainActivity::class.java).apply {
                    action = ACTION_WIDGET_NEXT
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                }
                context.startActivity(appIntent)
            }
        }
    }

    private fun updateAllWidgets(context: Context) {
        val appWidgetManager = AppWidgetManager.getInstance(context)
        val thisWidget = ComponentName(context, KanyePlayerWidgetProvider::class.java)
        val appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    private fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
        val views = RemoteViews(context.packageName, R.layout.kanye_player_widget_layout)

        // Set song metadata
        views.setTextViewText(R.id.widget_song_title, currentTitle)
        views.setTextViewText(R.id.widget_song_artist, currentArtist)

        // Set proper Play/Pause icon state
        val playIcon = if (isPlaying) {
            android.R.drawable.ic_media_pause
        } else {
            android.R.drawable.ic_media_play
        }
        views.setImageViewResource(R.id.widget_play_pause, playIcon)

        // Bind Play/Pause PendingIntent
        val playPauseIntent = Intent(context, KanyePlayerWidgetProvider::class.java).apply {
            action = ACTION_WIDGET_PLAY_PAUSE
        }
        val playPausePendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            playPauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_play_pause, playPausePendingIntent)

        // Bind Next PendingIntent
        val nextIntent = Intent(context, KanyePlayerWidgetProvider::class.java).apply {
            action = ACTION_WIDGET_NEXT
        }
        val nextPendingIntent = PendingIntent.getBroadcast(
            context,
            1,
            nextIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_next, nextPendingIntent)

        // Clicking the text details will launch the main Player screen
        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            context,
            2,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_song_title, openAppPendingIntent)

        // Instruct the widget manager to update the widget
        appWidgetManager.updateAppWidget(appWidgetId, views)
    }
}
