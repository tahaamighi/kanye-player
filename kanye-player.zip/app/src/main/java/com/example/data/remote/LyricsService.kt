package com.example.data.remote

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class LyricLine(
    val timestampMs: Long,
    val text: String
)

data class Part(val text: String? = null)

data class Content(val parts: List<Part>)

data class GenerateContentRequest(
    val contents: List<Content>
)

data class Candidate(val content: Content)

data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object LyricsService {
    private const val TAG = "LyricsService"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val apiService: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }

    /**
     * Fetches synced lyrics in LRC format from Gemini API online.
     * Fallbacks to packaged local synced lyrics if API is missing, fails, or is offline.
     */
    suspend fun fetchSyncedLyrics(title: String, artist: String): List<LyricLine> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API key is not configured. Falling back to local lyrics.")
            return@withContext getLocalFallbackLyrics(title)
        }

        val prompt = """
            You are a music synchronization lyrics database service.
            Find and provide the synchronized lyrics in standard LRC format (using '[mm:ss.xx] Lyric Text' timestamps) for the song '$title' by '$artist'.
            Ensure the timeline covers the whole song (about 3-4 minutes) with appropriate spacing.
            Only return the lyrics in LRC format. Do not include any headers, explanation, markdown, code blocks (such as ```lrc or ```), or introductory text.
            If the song is not fully known, generate matching synchronized lyrics.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt))))
        )

        try {
            val response = apiService.generateContent(apiKey, request)
            val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (textResponse != null) {
                val cleanedText = textResponse.replace("```lrc", "").replace("```", "").trim()
                val parsed = parseLrc(cleanedText)
                if (parsed.isNotEmpty()) {
                    return@withContext parsed
                }
            }
            Log.w(TAG, "Empty or invalid response from Gemini. Using fallback.")
            getLocalFallbackLyrics(title)
        } catch (e: Exception) {
            Log.e(TAG, "Error calling Gemini lyrics service: ${e.message}", e)
            getLocalFallbackLyrics(title)
        }
    }

    /**
     * Parses LRC text lines into clean LyricLine objects.
     */
    fun parseLrc(lrcText: String): List<LyricLine> {
        val lines = lrcText.split("\n")
        val lyricLines = mutableListOf<LyricLine>()
        // Regex in raw string to avoid escape sequence issues
        val regex = Regex("""\[(\d+):(\d+)(?:[.:](\d+))?\](.*)""")

        for (line in lines) {
            val trimmed = line.trim()
            val match = regex.find(trimmed)
            if (match != null) {
                val min = match.groupValues[1].toLongOrNull() ?: 0L
                val sec = match.groupValues[2].toLongOrNull() ?: 0L
                val fractStr = match.groupValues[3]
                val fract = if (fractStr.isNotEmpty()) {
                    val parsedFract = fractStr.toLongOrNull() ?: 0L
                    if (fractStr.length == 2) parsedFract * 10 else parsedFract
                } else {
                    0L
                }
                val text = match.groupValues[4].trim()

                val timestampMs = (min * 60 + sec) * 1000 + fract
                lyricLines.add(LyricLine(timestampMs, text))
            }
        }
        return lyricLines.sortedBy { it.timestampMs }
    }

    /**
     * Static premium synced lyrics fallback for Kanye West classics when offline or without API key.
     */
    private fun getLocalFallbackLyrics(title: String): List<LyricLine> {
        val t = title.lowercase()
        val rawLrc = when {
            t.contains("runaway") -> """
                [00:00.00] (Intro - Iconic Single Piano Key)
                [00:03.50] *High-pitched piano chime repeats*
                [00:15.00] (Heavy bass kicks in)
                [00:30.00] Look at ya, look at ya, look at ya
                [00:35.00] Look at ya, look at ya, look at ya
                [00:40.00] Ladies and gentlemen, Leonard Bernstein!
                [00:44.00] And I always find, yeah, I always find something wrong
                [00:51.50] You been putting up with my business for way too long
                [00:59.00] I'm so gifted at finding what I don't like the most
                [01:06.50] So a toast to the scumbags, toast to the jerks
                [01:14.00] Toast to the players, toast to the fakes
                [01:19.50] Toast to the hearts that are broken in two
                [01:25.00] Let's have a toast for the douchebags
                [01:29.00] Let's have a toast for the assholes
                [01:32.50] Let's have a toast for the scumbags
                [01:36.00] Every one of them that I know
                [01:40.00] Let's have a toast for the jerkoffs
                [01:43.50] That'll never take work off
                [01:47.00] Baby, I got a plan, run away fast as you can
                [01:54.00] Run away from me, baby!
                [02:00.00] Run away! Run away from me, baby!
                [02:07.00] (Pusha T Verse incoming...)
            """.trimIndent()

            t.contains("stronger") -> """
                [00:00.00] (Vocals: N-N-Now th-that don't kill me)
                [00:05.00] (Can only make me stronger)
                [00:09.50] I need you to hurry up now, 'cause I can't school much longer
                [00:14.50] I know I got to be right now, 'cause I can't get much wronger
                [00:19.00] Man, I've been waiting all night now, that's how long I've been on ya
                [00:23.50] Work it harder, make it better
                [00:26.00] Do it faster, makes us stronger
                [00:28.50] More than ever, hour after hour
                [00:31.00] Our work is never over
                [00:33.00] Let's get lost tonight
                [00:35.50] You can be my black Kate Moss tonight
                [00:38.00] Play security, let's get lost tonight
                [00:42.50] N-now th-that don't kill me
                [00:46.00] Can only make me stronger!
                [00:49.00] I need you to hurry up now, 'cause I can't wait much longer
            """.trimIndent()

            t.contains("heartless") -> """
                [00:00.00] (808 Bass Chords - Synth Strings)
                [00:06.00] In the night, I hear 'em talk, the coldest story ever told
                [00:12.50] Somewhere far along this road, he lost his soul to a woman so heartless
                [00:19.50] How could you be so heartless?
                [00:24.00] Oh, how could you be so heartless?
                [00:27.50] How could you be so Dr. Evil?
                [00:30.00] You bringing home a side of you that I don't know
                [00:33.50] I decided to let you go, but remember
                [00:37.00] You'll never find nobody better than me!
                [00:41.00] Talking, talking, talking, 'bout how you don't wanna be with me
                [00:45.00] Talking, talking, talking, 'bout how I'll never be free
                [00:49.00] But in the end, it's gonna be me you see!
            """.trimIndent()

            t.contains("power") -> """
                [00:00.00] (Heavy clap and vocal chant: Aaaah-yeah!)
                [00:06.00] I'm living in the 21st century
                [00:08.50] Doing something mean to it
                [00:11.00] Do it better than anybody you ever seen do it
                [00:13.50] Screams from the haters, got a nice ring to it
                [00:16.00] I guess every superhero need his theme music
                [00:19.00] No one man should have all that POWER
                [00:24.00] The clock's ticking, I just count the HOURS
                [00:29.00] Stop tripping, I'm tripping off the POWER
                [00:33.00] (Till then, fuck that, the world's ours!)
                [00:37.00] And then they'll say: "He's crazy, right?"
                [00:40.00] Yeah, I know, but I'm living for tonight!
            """.trimIndent()

            t.contains("flashing") -> """
                [00:00.00] (Smooth Violin Symphony Intro)
                [00:09.50] (Retro Synth Beat Kicks In)
                [00:18.00] Flashing lights...
                [00:22.50] She don't believe in shooting stars
                [00:25.00] But she believe in shoes and cars
                [00:27.50] Wood floors in the new apartment
                [00:29.50] Couture from the store's department
                [00:32.00] You more like "L'Art de la Mode"
                [00:34.00] I'm more of a "trips to Rome"
                [00:36.50] Flashing lights...
                [00:41.00] As I look at the flashing lights!
            """.trimIndent()

            t.contains("bound") -> """
                [00:00.00] (Soul sample: Bound to fall in love...)
                [00:05.50] (Kanye: Uh-huh, honey!)
                [00:08.00] Bound to fall in love
                [00:10.00] (Kanye: Yeezy season approachin'!)
                [00:12.50] All this closet space I'm givin' you
                [00:15.00] You're down with it, and I'm down with it too
                [00:18.00] I wanna choke you, but I love you
                [00:20.50] Let's leave before the morning's due
                [00:23.00] Bound to fall in love...
                [00:26.50] Uh-huh, honey!
            """.trimIndent()

            else -> """
                [00:00.00] (Kanye Player - Minimal Dark Visual Theme)
                [00:05.00] This is a synchronized lyric line.
                [00:10.00] Playing Yeezy classic track offline.
                [00:15.00] Auto-detected from directory scanner.
                [00:20.00] Tap 'Equalizer' to boost the 808s bass.
                [00:25.00] Check your Bluetooth settings in the top bar.
                [00:30.00] Music is the art of expressing the soul.
                [00:35.00] Kanye West - Master of beats.
                [00:40.00] "We're going to touch the sky."
                [00:45.00] Keep listening in high fidelity.
                [00:50.00] (Instrumental Bridge - 808 Bass Outro)
            """.trimIndent()
        }
        return parseLrc(rawLrc)
    }
}
