package com.example.data.repository

import com.example.data.local.AppSettings
import com.example.data.local.EqSettings
import com.example.data.local.MusicDao
import com.example.data.local.Playlist
import com.example.data.local.PlaylistTrackCrossRef
import com.example.data.local.PlaylistWithTracks
import com.example.data.local.Track
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.io.File

class MusicRepository(private val musicDao: MusicDao) {

    val allTracks: Flow<List<Track>> = musicDao.getAllTracks()
    val allPlaylists: Flow<List<Playlist>> = musicDao.getAllPlaylists()
    val allPlaylistsWithTracks: Flow<List<PlaylistWithTracks>> = musicDao.getAllPlaylistsWithTracks()
    val appSettings: Flow<AppSettings?> = musicDao.getAppSettings()

    suspend fun getTrackById(id: Int): Track? = musicDao.getTrackById(id)

    suspend fun insertTrack(track: Track): Long = musicDao.insertTrack(track)

    suspend fun updateTrack(track: Track) = musicDao.updateTrack(track)

    suspend fun deleteTrack(track: Track) = musicDao.deleteTrack(track)

    suspend fun insertPlaylist(name: String): Long {
        return musicDao.insertPlaylist(Playlist(name = name))
    }

    suspend fun updatePlaylist(playlist: Playlist) = musicDao.updatePlaylist(playlist)

    suspend fun deletePlaylist(playlist: Playlist) = musicDao.deletePlaylist(playlist)

    suspend fun addTrackToPlaylist(playlistId: Int, trackId: Int) {
        musicDao.insertPlaylistTrack(PlaylistTrackCrossRef(playlistId, trackId))
    }

    suspend fun removeTrackFromPlaylist(playlistId: Int, trackId: Int) {
        musicDao.removeTrackFromPlaylist(playlistId, trackId)
    }

    fun getPlaylistWithTracks(playlistId: Int): Flow<PlaylistWithTracks?> {
        return musicDao.getPlaylistWithTracks(playlistId)
    }

    // Equalizer
    suspend fun getEqSettings(presetName: String): EqSettings {
        return musicDao.getEqSettings(presetName) ?: createDefaultPreset(presetName)
    }

    suspend fun saveEqSettings(settings: EqSettings) {
        musicDao.saveEqSettings(settings)
    }

    private fun createDefaultPreset(name: String): EqSettings {
        return when (name) {
            "Yeezus Bass Boost" -> EqSettings(name, 1.0f, 0.8f, 0.2f, 0.1f, 0.3f, 0.9f, 0.6f)
            "Graduation Synth" -> EqSettings(name, 0.3f, 0.5f, 0.8f, 0.9f, 0.4f, 0.5f, 0.7f)
            "808s Autotune" -> EqSettings(name, 0.6f, 0.4f, 0.5f, 0.6f, 0.8f, 0.7f, 0.8f)
            "Acoustic Minimalist" -> EqSettings(name, 0.1f, 0.2f, 0.6f, 0.5f, 0.4f, 0.2f, 0.3f)
            "Donda Ambient" -> EqSettings(name, 0.5f, 0.3f, 0.4f, 0.5f, 0.7f, 0.8f, 0.9f)
            else -> EqSettings(name, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f)
        }
    }

    // App Settings
    suspend fun saveAppSettings(settings: AppSettings) {
        musicDao.saveAppSettings(settings)
    }

    /**
     * Scans a local directory. Automatically identifies songs belonging to Kanye West, Kanye, or Ye,
     * adding them to the database and adding them automatically to a default "Yeezy Auto-Scanned" playlist.
     */
    suspend fun scanDirectoryForYeezyTracks(directoryPath: String): Int {
        val folder = File(directoryPath)
        if (!folder.exists() || !folder.isDirectory) return 0

        val detectedTracks = mutableListOf<Track>()
        
        // Scan the directory
        val files = folder.listFiles { file ->
            file.isFile && (file.name.endsWith(".mp3", ignoreCase = true) || 
                            file.name.endsWith(".wav", ignoreCase = true) || 
                            file.name.endsWith(".m4a", ignoreCase = true))
        } ?: emptyArray()

        for (file in files) {
            val name = file.nameWithoutExtension.lowercase()
            // Check if name contains Kanye, West, Ye, Yeezy, Yeezus
            if (name.contains("kanye") || name.contains("west") || name.equals("ye") || name.contains(" ye ") || name.contains("ye_") || name.contains("yeezy") || name.contains("yeezus") || name.contains("donda") || name.contains("heartless") || name.contains("stronger") || name.contains("runaway") || name.contains("flashing lights") || name.contains("bound 2")) {
                
                // Parse some details if possible or use smart defaults
                val cleanName = file.nameWithoutExtension
                    .replace(Regex("(?i)kanye west"), "")
                    .replace(Regex("(?i)kanye"), "")
                    .replace(Regex("(?i)west"), "")
                    .replace(Regex("(?i)ye"), "")
                    .replace(Regex("[_\\-]"), " ")
                    .trim()

                val title = if (cleanName.isEmpty()) file.nameWithoutExtension else cleanName
                
                val album = determineAlbumBySongTitle(title)
                val year = determineYearByAlbum(album)

                detectedTracks.add(
                    Track(
                        title = title.capitalizeWords(),
                        artist = "Kanye West",
                        album = album,
                        year = year,
                        filePath = file.absolutePath,
                        durationMs = 210000L, // Default 3.5 minutes
                        isOffline = true,
                        isFavorite = false
                    )
                )
            }
        }

        if (detectedTracks.isNotEmpty()) {
            // Save in DB
            musicDao.insertTracks(detectedTracks)
            
            // Get or create "Yeezy Auto-Scanned" playlist
            val playlists = musicDao.getAllPlaylists().firstOrNull() ?: emptyList()
            var autoPlaylist = playlists.find { it.name == "Yeezy Auto-Scanned" }
            val playlistId = if (autoPlaylist == null) {
                musicDao.insertPlaylist(Playlist(name = "Yeezy Auto-Scanned"))
            } else {
                autoPlaylist.id.toLong()
            }

            // Bind detected tracks to this playlist
            val allInsertedTracks = musicDao.getAllTracks().firstOrNull() ?: emptyList()
            for (track in detectedTracks) {
                val dbTrack = allInsertedTracks.find { it.filePath == track.filePath }
                if (dbTrack != null) {
                    musicDao.insertPlaylistTrack(PlaylistTrackCrossRef(playlistId.toInt(), dbTrack.id))
                }
            }
        }

        return detectedTracks.size
    }

    /**
     * Seeds beautiful demo Kanye West tracks with accurate release years and album associations
     * to ensure the application is immediately playable and fully immersive out of the box.
     */
    suspend fun seedDemoYeezyTracks() {
        val demoTracks = listOf(
            Track(
                title = "Runaway",
                artist = "Kanye West (feat. Pusha T)",
                album = "My Beautiful Dark Twisted Fantasy",
                year = 2010,
                filePath = "/demo/runaway.mp3",
                durationMs = 548000L,
                isOffline = true,
                isFavorite = true
            ),
            Track(
                title = "Stronger",
                artist = "Kanye West",
                album = "Graduation",
                year = 2007,
                filePath = "/demo/stronger.mp3",
                durationMs = 311000L,
                isOffline = true,
                isFavorite = true
            ),
            Track(
                title = "Power",
                artist = "Kanye West",
                album = "My Beautiful Dark Twisted Fantasy",
                year = 2010,
                filePath = "/demo/power.mp3",
                durationMs = 292000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Heartless",
                artist = "Kanye West",
                album = "808s & Heartbreak",
                year = 2008,
                filePath = "/demo/heartless.mp3",
                durationMs = 211000L,
                isOffline = true,
                isFavorite = true
            ),
            Track(
                title = "Flashing Lights",
                artist = "Kanye West (feat. Dwele)",
                album = "Graduation",
                year = 2007,
                filePath = "/demo/flashing_lights.mp3",
                durationMs = 237000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Bound 2",
                artist = "Kanye West",
                album = "Yeezus",
                year = 2013,
                filePath = "/demo/bound2.mp3",
                durationMs = 229000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Black Skinhead",
                artist = "Kanye West",
                album = "Yeezus",
                year = 2013,
                filePath = "/demo/black_skinhead.mp3",
                durationMs = 188000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Praise God",
                artist = "Kanye West",
                album = "Donda",
                year = 2021,
                filePath = "/demo/praise_god.mp3",
                durationMs = 226000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Gold Digger",
                artist = "Kanye West (feat. Jamie Foxx)",
                album = "Late Registration",
                year = 2005,
                filePath = "/demo/gold_digger.mp3",
                durationMs = 208000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Ultralight Beam",
                artist = "Kanye West",
                album = "The Life of Pablo",
                year = 2016,
                filePath = "/demo/ultralight_beam.mp3",
                durationMs = 320000L,
                isOffline = true,
                isFavorite = true
            ),
            Track(
                title = "Jesus Walks",
                artist = "Kanye West",
                album = "The College Dropout",
                year = 2004,
                filePath = "/demo/jesus_walks.mp3",
                durationMs = 193000L,
                isOffline = true,
                isFavorite = false
            ),
            Track(
                title = "Carnival",
                artist = "¥$ (Ye & Ty Dolla \$ign)",
                album = "Vultures 1",
                year = 2024,
                filePath = "/demo/carnival.mp3",
                durationMs = 264000L,
                isOffline = true,
                isFavorite = true
            )
        )

        // Delete old and seed
        musicDao.deleteAllTracks()
        musicDao.insertTracks(demoTracks)

        // Seed default playlists
        val currentPlaylists = musicDao.getAllPlaylists().firstOrNull() ?: emptyList()
        if (currentPlaylists.isEmpty()) {
            val essentialId = musicDao.insertPlaylist(Playlist(name = "Essential Yeezy"))
            val favoritesId = musicDao.insertPlaylist(Playlist(name = "My Faves"))

            val insertedTracks = musicDao.getAllTracks().firstOrNull() ?: emptyList()
            for ((index, track) in insertedTracks.withIndex()) {
                if (index % 2 == 0) {
                    musicDao.insertPlaylistTrack(PlaylistTrackCrossRef(essentialId.toInt(), track.id))
                }
                if (track.isFavorite) {
                    musicDao.insertPlaylistTrack(PlaylistTrackCrossRef(favoritesId.toInt(), track.id))
                }
            }
        }
    }

    private fun determineAlbumBySongTitle(title: String): String {
        val t = title.lowercase()
        return when {
            t.contains("runaway") || t.contains("power") || t.contains("gorgeous") || t.contains("all of the lights") || t.contains("monster") || t.contains("devil in a new dress") -> "My Beautiful Dark Twisted Fantasy"
            t.contains("stronger") || t.contains("flashing lights") || t.contains("can't tell me nothing") || t.contains("good life") || t.contains("homecoming") || t.contains("champion") -> "Graduation"
            t.contains("heartless") || t.contains("love lockdown") || t.contains("amazing") || t.contains("say you will") || t.contains("paranoid") || t.contains("coldest winter") -> "808s & Heartbreak"
            t.contains("bound 2") || t.contains("black skinhead") || t.contains("new slaves") || t.contains("blood on the leaves") || t.contains("on sight") -> "Yeezus"
            t.contains("praise god") || t.contains("hurricane") || t.contains("off the grid") || t.contains("jail") || t.contains("moon") || t.contains("heaven and hell") -> "Donda"
            t.contains("gold digger") || t.contains("touch the sky") || t.contains("heard 'em say") || t.contains("hey mama") || t.contains("diamonds from sierra leone") -> "Late Registration"
            t.contains("jesus walks") || t.contains("all falls down") || t.contains("through the wire") || t.contains("spaceships") || t.contains("slow jamz") -> "The College Dropout"
            t.contains("ultralight beam") || t.contains("famous") || t.contains("father stretch my hands") || t.contains("real friends") || t.contains("no more parties in la") || t.contains("waves") -> "The Life of Pablo"
            t.contains("ghost town") || t.contains("yikes") || t.contains("all mine") || t.contains("violent crimes") -> "Ye"
            t.contains("carnival") || t.contains("stars") || t.contains("burn") || t.contains("talking") || t.contains("vultures") -> "Vultures 1"
            else -> "Yeezy Archive"
        }
    }

    private fun determineYearByAlbum(album: String): Int {
        return when (album) {
            "The College Dropout" -> 2004
            "Late Registration" -> 2005
            "Graduation" -> 2007
            "808s & Heartbreak" -> 2008
            "My Beautiful Dark Twisted Fantasy" -> 2010
            "Yeezus" -> 2013
            "The Life of Pablo" -> 2016
            "Ye" -> 2018
            "Jesus Is King" -> 2019
            "Donda" -> 2021
            "Vultures 1" -> 2024
            "Vultures 2" -> 2024
            else -> 2025
        }
    }

    private fun String.capitalizeWords(): String = split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }
}
